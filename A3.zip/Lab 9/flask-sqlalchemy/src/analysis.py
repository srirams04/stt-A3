import json

# Load the dependency data from the alchemy_deps.json file
with open("alchemy_deps.json", "r") as file:
    dependency_data = json.load(file)

# Calculate fan-in and fan-out for each module
module_metrics = {}

# Initialize the metrics dictionary
for module_name in dependency_data:
    module_metrics[module_name] = {
        "fan_in": 0,  # Number of modules that import this module
        "fan_out": 0  # Number of modules that this module imports
    }

# Calculate fan-out (number of imports each module has)
for module_name, module_info in dependency_data.items():
    if "imports" in module_info:
        module_metrics[module_name]["fan_out"] = len(module_info["imports"])

# Calculate fan-in (number of times each module is imported by others)
for module_name, module_info in dependency_data.items():
    if "imported_by" in module_info:
        module_metrics[module_name]["fan_in"] = len(module_info["imported_by"])

# Print the results in a readable format
print("\nModule Dependency Analysis for Flask-SQLAlchemy:")
print("="*60)
print(f"{'Module Name':<40} | {'Fan-In':<8} | {'Fan-Out':<8}")
print("-"*60)

# Sort modules by combined fan-in and fan-out for better visibility of highly coupled modules
sorted_modules = sorted(
    module_metrics.items(),
    key=lambda x: x[1]["fan_in"] + x[1]["fan_out"],
    reverse=True
)

for module_name, metrics in sorted_modules:
    print(f"{module_name:<40} | {metrics['fan_in']:<8} | {metrics['fan_out']:<8}")

# Save the results to a file
with open("flask_sqlalchemy_dependency_metrics.json", "w") as output_file:
    json.dump(module_metrics, output_file, indent=4)

print("\nDetailed metrics saved to flask_sqlalchemy_dependency_metrics.json")

# Identify core modules (highest fan-in or fan-out)
print("\nCore Modules Analysis:")
print("-"*60)
core_threshold = 3  # Modules with fan-in or fan-out >= this value are considered core

for module_name, metrics in sorted_modules:
    if metrics["fan_in"] >= core_threshold or metrics["fan_out"] >= core_threshold:
        print(f"Core Module: {module_name}")
        print(f"  Fan-In: {metrics['fan_in']} | Fan-Out: {metrics['fan_out']}")
        print(f"  Impact Level: {'High' if metrics['fan_in'] + metrics['fan_out'] > 5 else 'Medium'}")
        print("-"*40)