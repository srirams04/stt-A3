import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Load the CSV file
df = pd.read_csv('TypeMetrics.csv')

# Sort classes by LCOM5 (normalized between 0-1) for better analysis
sorted_df = df.sort_values(by='LCOM5', ascending=False)

# Create a function to categorize cohesion quality
def categorize_cohesion(row):
    if row['LCOM5'] >= 0.7:
        return 'Poor'
    elif row['LCOM5'] >= 0.4:
        return 'Moderate'
    else:
        return 'Good'

# Add category column
sorted_df['Cohesion Quality'] = sorted_df.apply(categorize_cohesion, axis=1)

# Print detailed analysis
print("=== LCOM Cohesion Analysis for Spring PetClinic ===\n")
print(f"Total classes analyzed: {len(sorted_df)}")

# Count classes by cohesion quality
quality_counts = sorted_df['Cohesion Quality'].value_counts()
print("\nCohesion Quality Distribution:")
for quality, count in quality_counts.items():
    percentage = (count / len(sorted_df)) * 100
    print(f"- {quality}: {count} classes ({percentage:.1f}%)")

# Identify classes with the highest LCOM values
print("\nTop 5 Classes with Poorest Cohesion (Highest LCOM5):")
poor_classes = sorted_df.head(5)
for index, row in poor_classes.iterrows():
    print(f"- {row['Type Name']}: LCOM5={row['LCOM5']:.3f}, LCOM1={row['LCOM1']}")

# Identify perfect candidates for refactoring (LCOM5 = 1.0)
perfect_candidates = sorted_df[sorted_df['LCOM5'] == 1.0]
if len(perfect_candidates) > 0:
    print("\nClasses with Perfect LCOM5 (1.0) - Immediate Refactoring Candidates:")
    for index, row in perfect_candidates.iterrows():
        print(f"- {row['Type Name']}")

# Plot LCOM5 values
plt.figure(figsize=(12, 8))
classes = sorted_df['Type Name']
lcom5_values = sorted_df['LCOM5']

# Create color mapping
colors = sorted_df['Cohesion Quality'].map({'Good': 'green', 'Moderate': 'orange', 'Poor': 'red'})

plt.bar(classes, lcom5_values, color=colors)
plt.xticks(rotation=90)
plt.ylabel('LCOM5 Value (Higher is Worse)')
plt.title('Class Cohesion Analysis - LCOM5 Values')
plt.tight_layout()

# Save the plot
plt.savefig('lcom_analysis.png')
print("\nAnalysis chart saved as 'lcom_analysis.png'")

# Print detailed recommendations for the worst classes
print("\nDetailed Recommendations for Top 3 Problematic Classes:")

worst_classes = sorted_df.head(3)
for index, row in worst_classes.iterrows():
    print(f"\n{row['Type Name']} (LCOM5: {row['LCOM5']:.3f}):")
    print("Potential issues:")
    
    if row['LCOM1'] > 30:
        print("- Extremely high number of method pairs not sharing attributes")
    
    if row['LCOM5'] > 0.8:
        print("- Methods operating independently with minimal attribute sharing")
    
    print("Recommendation:")
    if 'Controller' in row['Type Name']:
        print("- Split into multiple specialized controllers by functionality")
        print("- Consider extracting service classes for business logic")
    elif row['Type Name'] in ['Owner', 'Pet', 'Vet']:
        print("- Extract specialized classes for different aspects of the entity")
        print("- Consider using composition instead of putting everything in one class")
    else:
        print("- Perform class-level refactoring to increase method-attribute cohesion")
        print("- Consider applying Single Responsibility Principle more strictly")

print("\nAnalysis complete!")