﻿using System;

class Calculator
{
    static void Main()
    {
        try
        {
            Console.Write("Enter first number: ");
            int num1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter second number: ");
            int num2 = Convert.ToInt32(Console.ReadLine());

            int sum = num1 + num2;
            int diff = num1 - num2;
            int prod = num1 * num2;
            int div = num1 / num2;

            Console.WriteLine($"Sum: {sum}");
            Console.WriteLine($"Difference: {diff}");
            Console.WriteLine($"Product: {prod}");
            Console.WriteLine($"Quotient: {div}");

            if (sum % 2 == 0)
                Console.WriteLine("The sum is even.");
            else
                Console.WriteLine("The sum is odd.");
        }
        catch (DivideByZeroException)
        {
            Console.WriteLine("Cannot divide by zero.");
        }
        catch (FormatException)
        {
            Console.WriteLine("Invalid input. Please enter numeric values.");
        }
    }
}
