﻿using System;

class Program
{
    static void Main(string[] args)
    {
        // For loop from 1 to 10
        Console.WriteLine("Numbers from 1 to 10:");
        for (int i = 1; i <= 10; i++)
        {
            Console.Write(i + " ");
        }
        Console.WriteLine("\n");

        // While loop to take input until "exit" is typed
        string input = "";
        while (true)
        {
            Console.Write("Enter a number to find its factorial (or type 'exit' to quit): ");
            input = Console.ReadLine();

            if (input.Equals("exit", StringComparison.CurrentCultureIgnoreCase))
                break;

            try
            {
                int number = Convert.ToInt32(input);
                long factorial = CalculateFactorial(number);
                Console.WriteLine($"Factorial of {number} is {factorial}\n");
            }
            catch (FormatException)
            {
                Console.WriteLine("Invalid input! Please enter a valid number.\n");
            }
        }
    }

    static long CalculateFactorial(int n)
    {
        long result = 1;
        for (int i = 2; i <= n; i++)
        {
            result *= i;
        }
        return result;
    }
}
