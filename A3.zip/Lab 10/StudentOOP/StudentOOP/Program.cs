﻿
using System;

class Student
{
    public string Name { get; set; }
    public string ID { get; set; }
    public int Marks { get; set; }

    public Student(string name, string id, int marks)
    {
        Name = name;
        ID = id;
        Marks = marks;
    }

    public string GetGrade()
    {
        if (Marks >= 90) return "A";
        else if (Marks >= 75) return "B";
        else if (Marks >= 60) return "C";
        else return "D";
    }

    public void Display()
    {
        Console.WriteLine($"Name: {Name}, ID: {ID}, Marks: {Marks}, Grade: {GetGrade()}");
    }

    static void main()
    {
        Student s = new Student("Arjun", "CS202005", 88);
        s.Display();
    }
}

// StudentIITGN.cs
class StudentIITGN : Student
{
    public string Hostel_Name_IITGN { get; set; }

    public StudentIITGN(string name, string id, int marks, string hostel)
        : base(name, id, marks)
    {
        Hostel_Name_IITGN = hostel;
    }

    public new static void Main()
    {
        StudentIITGN student = new StudentIITGN("Riya", "CS202012", 93, "D4");
        student.Display();
        Console.WriteLine($"Hostel: {student.Hostel_Name_IITGN}");
    }
}
